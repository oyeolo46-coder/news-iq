"""News IQ - Automated News-to-Video Pipeline"""
